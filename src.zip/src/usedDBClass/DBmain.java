package usedDBClass;

import java.sql.ResultSet;
import java.sql.SQLException;

public class DBmain {
	static DB db = new DB();
	public static void main(String[] args) {
		displayTblCD("tblCb", "SELECT * FROM tblCB");
		displayTblCD("Sorted by title", "SELECT * FROM tblCB ORDER BY Title");
		displayTblCD("More than 10 songs", "SELECT * FROM tblCB WHERE [Number of Songs] > 10");
	}

	static void displayTblCD(String heading, String sql){
		System.out.println();
		System.out.println(heading);
		System.out.println();

		try{
			ResultSet resultSet = db.queryDB(sql);

			while(resultSet.next()){
				String t = resultSet.getString("Title");
				String a = resultSet.getString("Artist");
				int n = resultSet.getInt("Number of Songs");
				String g = resultSet.getString("Genre");

				System.out.println(t + " " + a + " " + n + " " + g);
			}
		}catch (SQLException e){
			System.out.println("SQL exception:\n" + e);
		}
	}

	static String addSpaces(String s, int width){
		String temp = " ";
		for(int i = 0; i < width - s.length(); i++) {
			temp += " ";
		}
		return temp;
	}
}
