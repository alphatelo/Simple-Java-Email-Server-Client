package usedDBClass;

import java.sql.*;

public class DB {
	private static final String driver = "net.ucanaccess.jdbc.UcanaccessDriver";
	private static final String url = "jdbc:ucanaccess://C:\\Users\\User\\Documents\\School\\IT\\ACCESS\\CBdatabase.accdb";

	private Connection connection;
	private PreparedStatement statement;
	private ResultSet resultSet;

	public DB(){
		try{
			Class.forName(driver);
			System.out.println("Driver successfully loaded");
		}catch (ClassNotFoundException c){
			System.out.println("Class not found:\n" + c);
		}

		try{
			connection = DriverManager.getConnection(url);
			System.out.println("Successfully connected");
		}catch (SQLException e) {
			System.out.println("Unable to connect:\n" + e);
		}

	}

	public ResultSet queryDB(String stmt) throws SQLException{
		statement = connection.prepareStatement(stmt);
		resultSet = statement.executeQuery();
		return resultSet;
	}
}
