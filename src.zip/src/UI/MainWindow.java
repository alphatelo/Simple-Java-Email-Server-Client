package UI;

import Client.ClientSocket3;
import Client.CurrentUser;
import Client.EmailList;
import Client.TemporaryEmailStorage;

import javax.swing.*;
import java.awt.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class MainWindow {
    public ClientSocket3 clientSocket3 = new ClientSocket3();
    public JFrame mainWindow = new JFrame("Courier");

    public static JPanel mainPanel = new JPanel();
    public static JPanel emailListPanel = new JPanel();
    public static JPanel emailPanel  = new JPanel();
    public static JPanel displayEmailPanel = new JPanel();

    private static final JLabel noEmailsLabel = new JLabel();

    public static JList<String> listOfEmails;

    public static JTextField emailAddressTextField = new JTextField();
    public static JTextField emailSubjectTextField = new JTextField();

    public static JButton send = new JButton("send");
    public static JButton compose = new JButton("compose");

    public JScrollPane scrollPane = new JScrollPane();
    public static JTextPane emailTextPane = new JTextPane();
    public static JTextPane displayEmailPane = new JTextPane();

    public void start() {
        mainWindow.setBounds(500, 80, 1000, 650);
        mainPanel.setLayout(null);
        mainWindow.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                clientSocket3.setProtocol(-1);
                try {
                    Thread.sleep(100);
                }catch(Exception exception) {
                    exception.printStackTrace();
                }
                System.exit(0);
            }
        });

        setMainPanel();
        //setEmailListPanel();
        mainWindow.setContentPane(mainPanel);
        JFrame.setDefaultLookAndFeelDecorated(true);
        mainWindow.setVisible(true);
    }

    public void setMainPanel() {
        setEmailListPanel();
        setEmailPanel();

        mainPanel.setBounds(0, 0, 1000, 650);
        mainPanel.setLayout(null);

        mainPanel.add(emailPanel);
        mainPanel.add(emailListPanel);
    }

    public void setEmailPanel() {
        emailPanel.setBounds(210, 0, 790, 650);
        emailPanel.setLayout(null);
        emailPanel.setBackground(Color.LIGHT_GRAY);

        setEmailTextPane();
        setButtonsEmailPanel();
        setEmailAddressTextField();
        setEmailSubjectTextField();

        emailPanel.add(emailAddressTextField);
        emailPanel.add(emailSubjectTextField);
        emailPanel.add(emailTextPane);
        emailPanel.add(send);
    }

    public void setEmailListPanel() {
        emailListPanel.setBounds(0, 0, 200, 650);
        emailListPanel.setLayout(null);

        setEmailList();

        emailListPanel.add(listOfEmails);
    }

    public static void setDisplayEmailPanel(String emails) {
        displayEmailPanel.setBounds(210, 0, 790, 650);
        displayEmailPanel.setLayout(null);
        displayEmailPanel.setBackground(Color.LIGHT_GRAY);

        emailPanel.remove(emailAddressTextField);
        emailPanel.remove(emailSubjectTextField);
        emailPanel.remove(emailTextPane);
        emailPanel.remove(send);

        setDisplayEmailPane(emails);

        compose.setBounds(645, 20, 110, 50);
        compose.addActionListener(actionEvent -> {
            mainPanel.remove(displayEmailPanel);
            mainPanel.add(emailPanel);
            mainPanel.revalidate();
        });

        emailPanel.add(displayEmailPane);
        emailPanel.add(compose);

        emailPanel.revalidate();
        mainPanel.revalidate();

    }

    public void setEmailList() {
        listOfEmails = EmailList.getListOfEmails();
        listOfEmails.setBounds(10, 10, 200, 600);
    }

    public void setEmailTextPane() {
        emailTextPane.setBounds(10, 130, 750, 470);
    }

    public static void setDisplayEmailPane(String emails) {
        displayEmailPane.setBounds(10, 130, 750, 470);
        displayEmailPane.setEditable(false);
        displayEmailPane.setText(emails);
    }

    public void setEmailAddressTextField() {
        emailAddressTextField.setBounds(10, 20, 180, 30);
    }

    public void setEmailSubjectTextField() {
        emailSubjectTextField.setBounds(10, 70, 180, 30);
    }

    public void setButtonsEmailPanel() {
        send.setBounds(645, 20, 110, 50);
        send.addActionListener(actionEvent -> {
            try {
                TemporaryEmailStorage.setTemporaryEmailStorage(emailAddressTextField.getText(), CurrentUser.getEmailAddress(), emailSubjectTextField.getText(), emailTextPane.getText());
            }catch (Exception e) {
                System.out.println("File not found bud: " + e);
            }

            clientSocket3.setProtocol(4);
        });
    }

    public static void setNoEmailsLabel() {
        noEmailsLabel.setBounds(75, 250, 100, 30);
        emailListPanel.remove(listOfEmails);
        emailListPanel.add(noEmailsLabel);
        noEmailsLabel.setText("No emails");
    }
}