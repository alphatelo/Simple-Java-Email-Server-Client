package UI;

import Client.ClientSocket3;
import Client.CurrentUser;

import javax.swing.*;
import java.awt.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.FileInputStream;

public class LoginWindow  {
    public static JFrame loginWindow = new JFrame("Login");
    public static MainWindow mainWindow = new MainWindow();
    public static ClientSocket3 clientSocket3 = new ClientSocket3();

    public void start() {
        loginWindow.setBounds(500, 200, 500, 350);
        loginWindow.setLayout(null);
        loginWindow.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                clientSocket3.setProtocol(-1);
                try {
                    Thread.sleep(100);
                } catch (InterruptedException ex) {
                    ex.printStackTrace();
                }
                System.exit(0);
            }
        });
        JFrame.setDefaultLookAndFeelDecorated(true);

        new LoginPanel(400, 400);
        loginWindow.setContentPane(LoginPanel.loginPanel);
        loginWindow.setVisible(true);
    }
}



class LoginPanel {
    public static JPanel loginPanel = new JPanel();

    protected static final JTextField emailAddressText = new JTextField();
    protected static final JTextField passwordText = new JTextField();

    protected static final JButton loginAccountButton = new JButton();
    protected static final JButton signUpScreenButton = new JButton();

    public static Font MyriadProRegular = null;

    public LoginPanel (int width, int length) {
        setFont();
        setTextFields();
        setButtons();

        loginPanel.add(emailAddressText);
        loginPanel.add(passwordText);
        loginPanel.add(loginAccountButton);
        loginPanel.add(signUpScreenButton);

        loginPanel.setSize(width, length);
        loginPanel.setLayout(null);
    }

    private static void setTextFields() {
        emailAddressText.setBounds(50, 100, 200, 30);
        emailAddressText.setFont(MyriadProRegular);

        passwordText.setBounds(50, 150, 200, 30);
        passwordText.setFont(MyriadProRegular);
    }

    private static void setButtons() {
        loginAccountButton.setBounds(50, 200, 90, 30);
        loginAccountButton.setText("Login");
        loginAccountButton.setFont(MyriadProRegular);

        signUpScreenButton.setBounds(160, 200, 90, 30);
        signUpScreenButton.setText("Sign Up");
        signUpScreenButton.setFont(MyriadProRegular);
        
        loginAccountButton.addActionListener(e -> {
            String emailAddress = emailAddressText.getText();
            String password = passwordText.getText();
            LoginWindow.clientSocket3.getDataLogin(emailAddress, password);
            LoginWindow.clientSocket3.setProtocol(1);

            try {
                Thread.sleep(1000);
            } catch (InterruptedException ex) {
                ex.printStackTrace();
            }

            if(LoginWindow.clientSocket3.getDone()) {
                //main screen logs in
                System.out.println("Logged in");
                new CurrentUser(emailAddress, password);
                LoginWindow.clientSocket3.setProtocol(3);
                ClientSocket3.setDone(false);
                try {
                    Thread.sleep(300);
                    LoginWindow.mainWindow.start();
                }catch (Exception exception) {
                    exception.printStackTrace();
                }
                LoginWindow.loginWindow.dispose();
            }else {
                //account does not exist
                System.out.println("Account does not exist/Incorrect password or email address");
            }
        });

        signUpScreenButton.addActionListener(e -> {
            new SignUpPanel();
            LoginWindow.loginWindow.setContentPane(loginPanel);
            loginPanel.revalidate();
        });
    }

    private static void setFont() {
        try {
            MyriadProRegular = Font.createFont(Font.TRUETYPE_FONT, new FileInputStream("C:\\Users\\mattk\\IdeaProjects\\EmailSoftware\\src\\Myriad Pro Regular.ttf")).deriveFont(Font.PLAIN, 15);
        } catch (Exception e) {
            System.out.println("Font error:\n" + e);
        }
    }
}



class SignUpPanel extends LoginPanel {
    private static final JTextField firstNameText = new JTextField();
    private static final JTextField lastNameText = new JTextField();
    private static final JTextField confirmPasswordText = new JTextField();

    private static final JButton loginScreenButton = new JButton();
    protected static final JButton createAccountButton = new JButton();

    public SignUpPanel() {
        super(500, 500);
        LoginWindow.loginWindow.setSize(500, 500);
        setTextFields();
        setButtons();

        loginPanel.add(firstNameText);
        loginPanel.add(lastNameText);
        loginPanel.add(confirmPasswordText);

        loginPanel.add(loginScreenButton);
        loginPanel.add(createAccountButton);

        loginPanel.remove(signUpScreenButton);
        loginPanel.remove(loginAccountButton);
    }

    private static void setTextFields() {
        firstNameText.setBounds(50, 100, 200, 30);
        firstNameText.setFont(MyriadProRegular);

        lastNameText.setBounds(50, 150, 200, 30);
        lastNameText.setFont(MyriadProRegular);

        emailAddressText.setLocation(50, 200);

        passwordText.setLocation(50, 250);

        confirmPasswordText.setBounds(50, 300, 200, 30);
        confirmPasswordText.setFont(MyriadProRegular);
    }

    private static void setButtons() {
        loginScreenButton.setBounds(160, 350, 90, 30);
        loginScreenButton.setText("Back");
        loginScreenButton.setFont(MyriadProRegular);

        createAccountButton.setBounds(50, 350, 90, 30);
        createAccountButton.setText("Create");
        createAccountButton.setFont(MyriadProRegular);

        loginScreenButton.addActionListener(e -> {
            loginPanel.add(signUpScreenButton);
            loginPanel.add(loginAccountButton);

            LoginWindow.loginWindow.setSize(500, 350);

            loginAccountButton.setLocation(50, 200);
            signUpScreenButton.setLocation(160, 200);

            emailAddressText.setLocation(50, 100);
            passwordText.setLocation(50, 150);

            loginPanel.remove(firstNameText);
            loginPanel.remove(lastNameText);
            loginPanel.remove(confirmPasswordText);

            loginPanel.remove(loginScreenButton);
            loginPanel.remove(createAccountButton);

            LoginWindow.loginWindow.setContentPane(LoginPanel.loginPanel);
            loginPanel.revalidate();
        });

        createAccountButton.addActionListener(e -> {
            String firstName = firstNameText.getText();
            String lastName = lastNameText.getText();
            String emailAddress = LoginPanel.emailAddressText.getText();
            String password = LoginPanel.passwordText.getText();

            if(password.equals(confirmPasswordText.getText())) {
                LoginWindow.clientSocket3.getDataSignUp(firstName, lastName, emailAddress, password);
                LoginWindow.clientSocket3.setProtocol(2);

                try {
                    Thread.sleep(1000);
                } catch (InterruptedException ex) {
                    ex.printStackTrace();
                }

                if (LoginWindow.clientSocket3.getDone()) {
                    LoginWindow.clientSocket3.setProtocol(3);
                    ClientSocket3.setDone(false);
                    try {
                        Thread.sleep(300);
                        LoginWindow.mainWindow.start();
                    }catch (Exception exception) {
                        exception.printStackTrace();
                    }
                    LoginWindow.loginWindow.dispose();
                } else {
                    System.out.println("Account does not exist/Incorrect password or email address");
                }
            }else {
                //password does not match
            }
        });
    }
}
