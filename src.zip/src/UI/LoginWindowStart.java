package UI;

public class LoginWindowStart {
    public static void main(String[] args) {
        LoginWindow loginWindow = new LoginWindow();
        loginWindow.start();
    }
}
