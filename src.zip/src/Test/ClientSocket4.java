package Test;

import java.io.*;
import java.net.Socket;

public class ClientSocket4 {
    private int anInt = 0;
    public void start() {
        try {
            Socket socket = new Socket("192.168.1.140", 25565);
            running(socket);

        }catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void running(Socket socket) {
        try {
            PrintWriter out = new PrintWriter(new OutputStreamWriter(socket.getOutputStream()), true);
            BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));

            while(true) {
                System.out.println(anInt);
                if(anInt == 1) {
                    System.out.println("whore");
                }
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void setAnInt(int anInt) {
        this.anInt = anInt;
    }
}
