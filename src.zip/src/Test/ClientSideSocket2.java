package Test;

import java.io.*;
import java.net.Socket;

public class ClientSideSocket2 {
    public static void main(String[] args) {
        socket2();
    }

    public static void socket2() {
        try {
            Socket socket = new Socket("10.45.187.168", 25565);

            PrintWriter out = new PrintWriter(new OutputStreamWriter(socket.getOutputStream()), true);
            BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));

            BufferedReader systemIn = new BufferedReader(new InputStreamReader(System.in));
            String b = "";

            while (!b.equals("blue")) {
                b = systemIn.readLine();
                out.println(b);
                System.out.println(in.readLine());
            }

        }catch (IOException e) {
            e.printStackTrace();
        }
    }
}
