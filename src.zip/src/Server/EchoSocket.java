package Server;

import Database.CurrentUser;
import Database.DatabaseAccess;
import Database.NewUser;

import java.io.*;
import java.net.Socket;
import java.util.Objects;
import java.util.Scanner;

public class EchoSocket implements Runnable {
    protected Socket socket;


    public EchoSocket(Socket socket) {
        this.socket = socket;
    }

    public void run() {
        try {
            PrintWriter out = new PrintWriter(new OutputStreamWriter(socket.getOutputStream()), true);
            BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            boolean running = true;
            System.out.println(Thread.currentThread().getId());
            out.println("connected");

            while(running) {
                String line = in.readLine();
                if(Integer.parseInt(line) == 1) {
                    out.println(1);
                    if(receiveDataLogin(in.readLine())) {
                        out.println(true);
                    }
                }else if(Integer.parseInt(line) == 2) {
                    out.println(2);
                    if(receiveDataSignUp(in.readLine())) {
                        out.println(true);
                    }
                }else if(Integer.parseInt(line) == 3) {
                    out.println(3);
                    in.readLine();
                    out.println(sendDataEmailButtons());

                }else if(Integer.parseInt(line) == 4) {
                    out.println(4);
                    if(receiveDataEmail(in.readLine())) {
                        out.println(true);
                    }
//                    out.println(4);
//                    int fileSize = 19;
//                    int bytesRead;
//                    int current;
//                    byte[] byteFileSize = new byte[fileSize];
//                    InputStream inputStream = socket.getInputStream();
//                    FileOutputStream fileOutputStream = new FileOutputStream("C:\\Users\\mattk\\Documents\\EmailSoftware Data\\EmailStorage\\h\\h.txt");
//                    BufferedOutputStream bufferedOutputStream = new BufferedOutputStream(fileOutputStream);
//                    bytesRead = inputStream.read(byteFileSize, 0, byteFileSize.length);
//                    current = bytesRead;
//
//                    do {                                                                                        //I did not write this piece of code
//                        bytesRead = inputStream.read(byteFileSize, current, (byteFileSize.length-current));     //
//                        if(bytesRead >= 0) current += bytesRead;
//                    } while(bytesRead > -1);                                                                    //up to here
//
//                    bufferedOutputStream.write(byteFileSize, 0 , current);
//                    bufferedOutputStream.flush();
//                    System.out.println("File " + "h.txt" + " downloaded (" + current + " bytes read)");
                }else if(Integer.parseInt(line) == -1) {
                    //out.println("Disconnecting");
                    running = false;
                    System.out.println("Disconnected\n");
                    socket.close();
                }
            }
        }catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static boolean receiveDataLogin(String data) {
        CurrentUser user = new CurrentUser();
        System.out.println("receiveDataLogin: " + data);
        return user.loggedIn(data);
    }

    private static boolean receiveDataSignUp(String data) {
        NewUser newUser = new NewUser();
        System.out.println("receiveDataSignUp: " + data);
        return newUser.signedUp(data);
    }

    private static boolean receiveDataEmail(String email) {
        try {
            int i = 0;
            Scanner scanner = new Scanner(email).useDelimiter("&");
            String recipient = scanner.next();
            String sender = scanner.next();
            String subject = scanner.next();
            String contents = scanner.next();

            System.out.println("receiveDataEmail: " + recipient + " " + sender + " " + subject + " " + contents);

            if (!new File("C:\\Users\\mattk\\Documents\\EmailSoftware Data\\EmailStorage\\" + recipient).exists()) {
                return false;
            } else {
                System.out.println("receiveDataEmail: " + recipient + " " + sender + " " + subject + " " + contents);
                File file = new File("C:\\Users\\mattk\\Documents\\EmailSoftware Data\\EmailStorage\\" + recipient + "\\" + sender + ".txt");

                if(file.createNewFile()) {
                    FileWriter fileWriter = new FileWriter(file);
                    fileWriter.write(recipient + "&" + sender + "&" + subject + "&" + contents);
                    fileWriter.close();

                    return true;
                }else if(file.exists()) {
                    while (file.exists()) {
                        i++;
                        file = new File("C:\\Users\\mattk\\Documents\\EmailSoftware Data\\EmailStorage\\" + recipient + "\\" + sender + i + ".txt");
                    }
                    FileWriter fileWriter = new FileWriter(file);
                    fileWriter.write(recipient + "&" + sender + "&" + subject + "&" + contents);
                    fileWriter.close();

                    return true;
                }else {
                    return false;
                }
            }
        } catch(IOException e){
            e.printStackTrace();
            return false;
        }
    }

    private static String sendDataEmailButtons() {
        StringBuilder stringBuilder = new StringBuilder();
        File file = null;
        File folder = new File("C:\\Users\\mattk\\Documents\\EmailSoftware Data\\EmailStorage\\" + CurrentUser.getEmailAddress());
        File[] allEmails = folder.listFiles();

        if(allEmails != null) {
            try {
                stringBuilder.append(allEmails.length);
                for (int i = 0; i < Objects.requireNonNull(allEmails).length; i++) {
                    stringBuilder.append("&");
                    if (allEmails[i].isFile()) {
                        file = new File("C:\\Users\\mattk\\Documents\\EmailSoftware Data\\EmailStorage\\" + CurrentUser.getEmailAddress() + "\\" + allEmails[i].getName());
                    }
                    assert file != null;
                    Scanner scanner = new Scanner(new FileReader(file)).useDelimiter("&");
                    String recipient = scanner.next();
                    String name = DatabaseAccess.getNameOfEmail(recipient);
                    System.out.println(DatabaseAccess.getNameOfEmail(recipient));
                    String sender = scanner.next();
                    String subject = scanner.next();
                    String contents = scanner.next();

                    stringBuilder.append(i).append("#").append(recipient).append("#").append(name).append("#").append(subject).append("#").append(contents);
                }
            } catch (Exception e) {
                System.out.println("sendDataEmailButtons error: " + e);
            }
            System.out.println(stringBuilder);
            return stringBuilder.toString();
        }else {
            return "No emails";
        }
    }
}
