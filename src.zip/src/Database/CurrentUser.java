package Database;

import java.util.Scanner;

public class CurrentUser {
    private static String emailAddress;
    private static String password;

    public boolean loggedIn(String data) {
        Scanner scLine = new Scanner(data).useDelimiter("&");
        emailAddress = scLine.next();
        password = scLine.next();
        return loginUser(emailAddress, password);
    }

    private static boolean loginUser(String emailAddress, String password) {
        DatabaseAccess databaseAccess = new DatabaseAccess();
        System.out.println("loginUser: " + emailAddress + " " + password);
        return databaseAccess.accountDetails(emailAddress, password);
    }

    public static String getEmailAddress() {
        return emailAddress;
    }

    public static String getPassword() {
        return password;
    }
}

