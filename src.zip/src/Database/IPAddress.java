package Database;

public class IPAddress {
}
