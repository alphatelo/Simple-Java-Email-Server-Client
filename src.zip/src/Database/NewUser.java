package Database;

import java.util.Scanner;

public class NewUser {
    public boolean signedUp(String data) {
        Scanner scLine = new Scanner(data).useDelimiter("&");
        String firstName = scLine.next();
        String lastName = scLine.next();
        String emailAddress = scLine.next();
        String password = scLine.next();
        return addUser(firstName, lastName, emailAddress, password);
    }

    private static boolean addUser(String firstName, String lastName, String emailAddress, String password) {
        DatabaseAccess databaseAccess = new DatabaseAccess();
        System.out.println("addUser: " + firstName + " " + lastName + " " + emailAddress + " " + password);
        if(databaseAccess.addNewAccount(firstName, lastName, emailAddress, password)) {
            FolderFile.createNewUserFolder(emailAddress);
            return true;
        }else {
            return false;
        }
    }
}
