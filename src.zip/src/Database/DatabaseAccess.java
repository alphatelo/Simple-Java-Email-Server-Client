package Database;

import java.sql.*;

public class DatabaseAccess {
    private static final String driver = "net.ucanaccess.jdbc.UcanaccessDriver";
    private static final String url = "jdbc:ucanaccess://C:\\Users\\mattk\\Documents\\EmailSoftware Data\\Email Software.accdb";

    private static Connection connection;
    private static PreparedStatement preparedStatement;
    private static ResultSet resultSet;

    public DatabaseAccess() {
        try{
            Class.forName(driver);
        }catch (ClassNotFoundException c){
            System.out.println("Class not found:\n" + c);
        }

        try{
            connection = DriverManager.getConnection(url);
            System.out.println("Successfully connected");
        }catch (SQLException e) {
            System.out.println("Unable to connect:\n" + e);
        }
    }

    public static ResultSet query(String sql) throws SQLException {
        preparedStatement = connection.prepareStatement(sql);
        resultSet = preparedStatement.executeQuery();
        return resultSet;
    }

    public void update(String sql) throws SQLException {
        preparedStatement = connection.prepareStatement(sql);
        preparedStatement.executeUpdate();
    }


    public boolean accountDetails(String emailAddress, String password) {
        try {
            ResultSet rsFinalCheck = query("SELECT * FROM Users WHERE emailAddress = '" + emailAddress + "'AND password ='" + password + "'");
            String tblEmailAddress = null;
            String tblPassword = null;

            while (rsFinalCheck.next()) {

                tblEmailAddress = rsFinalCheck.getString("emailAddress");
                tblPassword = rsFinalCheck.getString("password");
            }

            assert tblEmailAddress != null;
            return tblEmailAddress.equals(emailAddress) && tblPassword.equals(password);

        } catch (Exception exception) {
            System.out.println("account details error");
            return false;
        }
    }

    public boolean addNewAccount(String firstName, String lastName, String emailAddress, String password) {
        try {
            update("INSERT INTO Users (firstName, lastName, emailAddress, password) VALUES ('" + firstName + "', '" + lastName + "', '" + emailAddress + "', '" + password + "')");
            return accountDetails(emailAddress, password);
        } catch (Exception exception) {
            System.out.println("System problem: " + exception);
            return false;
        }
    }

    public static String getNameOfEmail(String emailAddress) {
        String name = null;
        try {
            ResultSet resultSet = query("SELECT firstName, lastName, emailAddress " + "FROM Users " + "WHERE emailAddress = '" + emailAddress + "'");
            while(resultSet.next()) {
                name = resultSet.getString("firstName") + " " + resultSet.getString("lastName");
            }
        }catch (Exception e) {
            System.out.println("System problem: " + e);
        }
        return name;
    }
}
