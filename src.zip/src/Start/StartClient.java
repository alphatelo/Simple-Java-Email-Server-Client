package Start;

import Client.ClientSocket3;
import UI.LoginWindow;

public class StartClient {
    public static void main(String[] args) {
        LoginWindow loginWindow = new LoginWindow();
        loginWindow.start();
        new ClientSocket3();
        ClientSocket3.start();
    }
}
