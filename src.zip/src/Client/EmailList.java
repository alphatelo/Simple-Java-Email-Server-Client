package Client;

import UI.MainWindow;

import javax.swing.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.Arrays;

public class EmailList {
    public static String email;
    public static JList<String> listOfEmails;

    public static void setListOfEmails(String[] emails) {
        System.out.println(Arrays.toString(emails));
        listOfEmails = new JList<>(emails);
        listOfEmails.setFixedCellHeight(60);
        MouseListener mouseListener = new MouseAdapter() {
            public void mouseClicked(MouseEvent evt) {
                JList list = (JList)evt.getSource();
                if (evt.getClickCount() == 2) {
                    // Double-click detected
                    int index = list.locationToIndex(evt.getPoint());
                    MainWindow.setDisplayEmailPanel(ClientSocket3.emailsFromList.get(index));
                    System.out.println(ClientSocket3.emailsFromList.get(index));
                }
            }
        };
        listOfEmails.addMouseListener(mouseListener);
    }

    public static JList<String> getListOfEmails() {
        return listOfEmails;
    }
}
