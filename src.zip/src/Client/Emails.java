package Client;

public class Emails {

}
