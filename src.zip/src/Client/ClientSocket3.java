package Client;

import UI.MainWindow;

import java.io.*;
import java.net.Socket;
import java.util.HashMap;
import java.util.Scanner;

public class ClientSocket3 {
    private static int protocol = 0;
    private static boolean done = false;
    public static HashMap<Integer, String> emailsFromList = new HashMap<>();

    private static String firstName;
    private static String lastName;
    private static String emailAddress;
    private static String password;
    private static Socket socket;
    //private static OutputStream outputStream;

    public static void start() {
        try {
            socket = new Socket("192.168.1.191", 25565);
            running(socket);

        }catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void running(Socket socket) {
        try {
            PrintWriter out = new PrintWriter(new OutputStreamWriter(socket.getOutputStream()), true);
            BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            boolean running = true;
            System.out.println(in.readLine());

            while (running) {
                out.println(0);
                if(protocol == 1) {
                    out.println(1);
                    in.readLine();
                    out.println(sendDataLogin(emailAddress, password));
                    if(Boolean.parseBoolean(in.readLine())) {
                        setDone(true);
                        protocol = 0;
                    }
                }else if(protocol == 2) {
                    out.println(2);
                    in.readLine();
                    out.println(sendDataSignUp(firstName, lastName, emailAddress, password));
                    if(Boolean.parseBoolean(in.readLine())) {
                        setDone(true);
                        protocol = 0;
                    }
                }else if(protocol == 3) {
                    out.println(3);
                    in.readLine();
                    out.println();
                    receiveDataEmailList(in.readLine());
                    protocol = 0;
                }else if(protocol == 4) {
                    out.println(4);
                    in.readLine();
                    out.println(sendDataEmail1());
                    if(Boolean.parseBoolean(in.readLine())) {
                        System.out.println("Email Sent");
                        protocol = 0;
                    }

//                    in.readLine();
//                    byte[] fileBytes = sendDataEmail();
//                    BufferedInputStream bufferedInputStream = new BufferedInputStream(new FileInputStream("C:\\Users\\mattk\\Documents\\EmailSoftware Data\\Client\\" + CurrentUser.getEmailAddress() + ".txt"));
//                    bufferedInputStream.read(fileBytes, 0, fileBytes.length);
//                    outputStream = socket.getOutputStream();
//                    outputStream.write(fileBytes, 0, fileBytes.length);
//                    outputStream.close();
                }else if(protocol == -1) {
                    out.println(-1);
                    //outputStream.close();
                    //System.out.println(in.readLine());
                    socket.close();
                }
            }
        }catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void setProtocol(int protocol) {
        ClientSocket3.protocol = protocol;
        System.out.println("setProtocol: " + protocol);
    }

    public void getDataLogin(String emailAddress, String password) {
        ClientSocket3.emailAddress = emailAddress;
        ClientSocket3.password = password;
        System.out.println("getDataLogin: " + ClientSocket3.emailAddress + " " + ClientSocket3.password);
    }

    private static String sendDataLogin(String emailAddress, String password) {
        System.out.println("sendDataLogin: " + ClientSocket3.emailAddress + " " + ClientSocket3.password);
        return emailAddress + "&" + password;
    }

    public void getDataSignUp(String firstName, String lastName, String emailAddress, String password) {
        ClientSocket3.firstName = firstName;
        ClientSocket3.lastName = lastName;
        ClientSocket3.emailAddress = emailAddress;
        ClientSocket3.password = password;
        System.out.println("getDataSignUp: " + ClientSocket3.firstName + " " + ClientSocket3.lastName + " " + ClientSocket3.emailAddress + " " + ClientSocket3.password);
    }

    private static String sendDataSignUp(String firstName, String lastName, String emailAddress, String password) {
        System.out.println("sendDataSignUp: " + ClientSocket3.firstName + " " + ClientSocket3.lastName + " " + ClientSocket3.emailAddress + " " + ClientSocket3.password);
        return firstName + "&" + lastName + "&" + emailAddress + "&" + password;
    }

    public static void receiveDataEmailList(String data) {
        if(!data.equals("No emails")) {
            Scanner scLine = new Scanner(data).useDelimiter("&");
            System.out.println(data);
            int num = scLine.nextInt();
            String[] emails = new String[num];
            int i = 0;
            while (scLine.hasNext()) {
                Scanner scanner = new Scanner(scLine.next()).useDelimiter("#");
                String index = scanner.next();
                String recipient = scanner.next();
                String name = scanner.next();
                String subject = scanner.next();
                String contents = scanner.next();
                Client.TemporaryEmailStorage.setTemporaryEmailStorage(recipient, name, subject, contents);
                System.out.println(Client.TemporaryEmailStorage.getName());

                System.out.println(num);
                emails[i] = "<html><p style=\"font-size:11px;\">" + Client.TemporaryEmailStorage.getName() + "<br><p style=\"font-size:9px;\">" + "Subject: " + Client.TemporaryEmailStorage.getSubject();
                emailsFromList.put(i, contents);
                i++;
            }
            EmailList.setListOfEmails(emails);
        }else {
            MainWindow.setNoEmailsLabel();
        }
    }

    private static String sendDataEmail1() {
        System.out.println("sendDataEmail: " + Client.TemporaryEmailStorage.getTemporaryEmailStorage());
        return TemporaryEmailStorage.getTemporaryEmailStorage();
    }

    public static byte[] sendDataEmail() {
        File file = new File("C:\\Users\\mattk\\Documents\\EmailSoftware Data\\Client\\" + CurrentUser.getEmailAddress() + ".txt");
        byte[] fileBytes = new byte[(int) file.length()];
        try {
            BufferedInputStream bufferedInputStream = new BufferedInputStream(new FileInputStream(file));
            bufferedInputStream.read(fileBytes, 0, fileBytes.length);
            OutputStream outputStream = socket.getOutputStream();
            outputStream.write(fileBytes, 0, fileBytes.length);
//            socket.shutdownOutput();
//            out = new PrintWriter(new OutputStreamWriter(socket.getOutputStream()));

        } catch (Exception exception) {
            exception.printStackTrace();
        }
        return fileBytes;
    }

    public static void receiveDataEmail() {

    }

    public boolean getDone() {
        return done;
    }

    public static void setDone(boolean done) {
        ClientSocket3.done = done;
    }
}