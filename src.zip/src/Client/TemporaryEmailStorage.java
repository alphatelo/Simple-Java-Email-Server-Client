package Client;

public class TemporaryEmailStorage {
    private static String recipient;
    private static String name;
    private static String subject;
    private static String contents;

    private static String split;

    public static void setTemporaryEmailStorage(String recipient, String name, String subject, String contents) {
        Client.TemporaryEmailStorage.recipient = recipient;
        Client.TemporaryEmailStorage.name = name;
        Client.TemporaryEmailStorage.subject = subject;
        Client.TemporaryEmailStorage.contents = contents;

        split = recipient + "&" + name + "&" + subject + "&" + contents;
    }

    public static String getTemporaryEmailStorage() {
        return split;
    }

    public static String getRecipient() {
        return recipient;
    }

    public static String getName() {
        return name;
    }

    public static String getSubject() {
        return subject;
    }

    public static String getContents() {
        return contents;
    }

    public static String getSplit() {
        return split;
    }
}
