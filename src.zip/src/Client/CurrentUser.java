package Client;

public class CurrentUser {
    private static String emailAddress;
    private static String password;

    public CurrentUser(String emailAddress, String password) {
        CurrentUser.emailAddress = emailAddress;
        CurrentUser.password = password;
    }

    public static String getEmailAddress() {
        return emailAddress;
    }

    public static String getPassword() {
        return password;
    }
}
